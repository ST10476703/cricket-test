import javax.swing.JOptionPane;

public class CricketStatsInput {
    public static void main(String[] args) {
        String[] batsmen = {"Jacques Kallis", "Hashim Amla", "AB de Villiers"};
        String[] stadiums = {"Kingsmead", "St George's", "Wanderers"};

        int[][] defaultRuns = {
            {5000, 3800, 4200},
            {3500, 3700, 3900},
            {6200, 5000, 5200}
        };

        int[][] runs = new int[stadiums.length][batsmen.length];

        // Input loop
        for (int i = 0; i < stadiums.length; i++) {
            for (int j = 0; j < batsmen.length; j++) {
                boolean valid = false;
                while (!valid) {
                    String input = JOptionPane.showInputDialog(
                            null,
                            "Enter runs scored by " + batsmen[j] + " at " + stadiums[i] +
                                    " (Default = " + defaultRuns[i][j] + "):",
                            "Input Runs",
                            JOptionPane.QUESTION_MESSAGE
                    );

                    if (input == null || input.trim().isEmpty()) {
                        runs[i][j] = defaultRuns[i][j];
                        valid = true;
                    } else {
                        try {
                            runs[i][j] = Integer.parseInt(input.trim());
                            valid = true;
                        } catch (NumberFormatException e) {
                            JOptionPane.showMessageDialog(
                                    null,
                                    "Invalid number! Please enter again.",
                                    "Error",
                                    JOptionPane.ERROR_MESSAGE
                            );
                        }
                    }

                    JOptionPane.showMessageDialog(
                            null,
                            batsmen[j] + " at " + stadiums[i] + ": " + runs[i][j] + " runs",
                            "Confirmation",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                }
            }
        }

        // Build output
        StringBuilder output = new StringBuilder();
        output.append(String.format("%-12s | %-15s | %-12s | %-15s\n",
                "Stadium", batsmen[0], batsmen[1], batsmen[2]));
        output.append("-----------------------------------------------------------------\n");

        for (int i = 0; i < stadiums.length; i++) {
            output.append(String.format("%-12s | %-15d | %-12d | %-15d\n",
                    stadiums[i], runs[i][0], runs[i][1], runs[i][2]));

            int max = runs[i][0];
            String bestBatsman = batsmen[0];
            for (int j = 1; j < batsmen.length; j++) {
                if (runs[i][j] > max) {
                    max = runs[i][j];
                    bestBatsman = batsmen[j];
                }
            }
            output.append(">> Highest at " + stadiums[i] + ": " + bestBatsman + " (" + max + " runs)\n");
        }

        output.append("\n--- Total Runs by Each Batsman ---\n");
        for (int j = 0; j < batsmen.length; j++) {
            int total = 0;
            for (int i = 0; i < stadiums.length; i++) {
                total += runs[i][j];
            }
            output.append(batsmen[j] + ": " + total + " runs\n");
        }

        JOptionPane.showMessageDialog(null, output.toString(), "Cricket Statistics", JOptionPane.INFORMATION_MESSAGE);
    }
}
