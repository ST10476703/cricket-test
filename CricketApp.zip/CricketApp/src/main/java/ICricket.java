public interface ICricket {
    String getBatsman();
    String getStadium();
    int getRunsScored();
}

