import java.util.Scanner;

public class RunApplication {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Batsman's Name: ");
        String batsman = sc.nextLine();

        System.out.print("Enter Stadium Name: ");
        String stadium = sc.nextLine();

        System.out.print("Enter Total Runs Scored: ");
        int runs = sc.nextInt();

        CricketRunsScored record = new CricketRunsScored(batsman, stadium, runs);

        System.out.println("\n--- Cricket Report ---");
        record.printReport();

        sc.close();
    }
}

