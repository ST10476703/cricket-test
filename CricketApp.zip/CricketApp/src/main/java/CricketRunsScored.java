public class CricketRunsScored extends Cricket {
    public CricketRunsScored(String batsman, String stadium, int runsScored) {
        super(batsman, stadium, runsScored);
    }

    public void printReport() {
        System.out.println("Batsman: " + getBatsman());
        System.out.println("Stadium: " + getStadium());
        System.out.println("Total Runs Scored: " + getRunsScored());
    }
}
